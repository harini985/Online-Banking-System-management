---
name: Precision Fintech
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434656'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737688'
  outline-variant: '#c3c5d9'
  surface-tint: '#004ced'
  primary: '#003ec7'
  on-primary: '#ffffff'
  primary-container: '#0052ff'
  on-primary-container: '#dfe3ff'
  inverse-primary: '#b7c4ff'
  secondary: '#515f78'
  on-secondary: '#ffffff'
  secondary-container: '#d2e0fe'
  on-secondary-container: '#55637d'
  tertiary: '#005569'
  on-tertiary: '#ffffff'
  tertiary-container: '#006f89'
  on-tertiary-container: '#bcecff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001452'
  on-primary-fixed-variant: '#0038b6'
  secondary-fixed: '#d6e3ff'
  secondary-fixed-dim: '#b9c7e4'
  on-secondary-fixed: '#0d1c32'
  on-secondary-fixed-variant: '#39475f'
  tertiary-fixed: '#b7eaff'
  tertiary-fixed-dim: '#4cd6ff'
  on-tertiary-fixed: '#001f28'
  on-tertiary-fixed-variant: '#004e60'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Geist
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  stack-xl: 64px
---

## Brand & Style
This design system is engineered for a high-trust, modern fintech environment. It balances the stability of traditional banking with the agility of decentralized finance. The aesthetic is rooted in **Corporate Modernism** but elevated through **Glassmorphism** and futuristic lighting effects to signal innovation.

The target audience consists of digitally native professionals who demand technical precision and a seamless, high-performance experience. The emotional response is one of "Atmospheric Trust"—feeling secure while navigating a cutting-edge, transparent financial landscape. Visuals are clean, spacious, and characterized by high-fidelity details like multi-layered shadows and subtle motion.

## Colors
The palette is anchored by "Trust Blue," a high-vibrancy primary color that suggests reliability and digital fluency. 

- **Primary (#0052FF):** Used for main actions, active states, and brand signatures.
- **Secondary (#0A192F):** Used for high-contrast typography, deep-background containers, and navigation sidebars to provide a "grounded" feel.
- **Accent (#00D1FF):** Reserved for data visualization highlights, progress indicators, and interactive "glow" effects.
- **Neutral (#F8FAFC):** The primary canvas color, keeping the interface airy and professional.

Surface colors should utilize varying opacities of white (e.g., `rgba(255, 255, 255, 0.7)`) when layered over gradients to achieve the glassmorphic effect.

## Typography
Typography is driven by clarity and technical sophistication. **Hanken Grotesk** provides a sharp, contemporary edge for headlines, while **Inter** ensures maximum readability for complex financial data and long-form content. **Geist** is used specifically for labels, monospaced data points (like transaction IDs), and utility text to emphasize the futuristic, developer-grade precision of the platform.

Use tight letter-spacing on display headings to maintain a compact, premium look. For body text, ensure a generous line-height to maintain legibility during dense information tasks.

## Layout & Spacing
The layout follows a **Fixed Grid** model on desktop to maintain a sense of order and institutional stability, transitioning to a **Fluid Grid** on mobile devices. 

- **Grid:** A 12-column system is used for desktop (1280px max-width) with 24px gutters.
- **Rhythm:** All spacing must be a multiple of the 4px base unit. 
- **Padding:** Content cards use generous internal padding (min 24px) to emphasize the "clean" brand pillar.
- **Reflow:** On mobile, complex data tables should transform into card-based layouts, and sidebars should collapse into a bottom-anchored navigation bar for ergonomic accessibility.

## Elevation & Depth
Depth is achieved through a combination of **Glassmorphism** and **Ambient Multi-layered Shadows**. 

1.  **Surfaces:** Background elements are solid. Primary interaction cards use a semi-transparent white backdrop (`rgba(255, 255, 255, 0.6)`) with a `backdrop-filter: blur(20px)`.
2.  **Borders:** Each glass container features a 1px solid border at 10% opacity white to simulate light catching the edge of the "glass."
3.  **Shadows:** Use a "soft-stack" shadow technique. Instead of one heavy shadow, use three:
    *   An ambient occlusion shadow (small blur, low opacity).
    *   A mid-range directional shadow.
    *   A large, very diffused global shadow (e.g., `0 20px 50px rgba(0, 82, 255, 0.05)`).
4.  **Z-Index:** Navigation and Modals occupy the highest levels, utilizing increased blur (40px) to recede the background further.

## Shapes
The shape language is defined by large, welcoming radii that soften the technical nature of fintech. 

- **Standard Elements:** Buttons and input fields use a base of 0.5rem (8px).
- **Cards & Containers:** Primary containers utilize `rounded-lg` (1rem / 16px) or `rounded-xl` (1.5rem / 24px) to create the signature "modern card" look.
- **Interactive Elements:** Small chips and tags should be pill-shaped to differentiate them from actionable buttons.
- **Icons:** Use icons with a 2px stroke weight and slightly rounded terminals to match the typography.

## Components
### Buttons
Buttons feature a subtle linear gradient (Primary to Accent) at a 135-degree angle. On hover, the gradient intensity increases, and a soft glow shadow (tinted blue) appears.

### Modern Cards
The centerpiece of the design. These must include the 20px backdrop blur, a 1px inner border, and a 24px corner radius. Headlines inside cards should be `headline-sm`.

### Input Fields
Fields are minimal with a light gray fill (#F1F5F9). Upon focus, the border transitions to Primary Blue with a 4px soft outer glow. Icons (e.g., eye-slash for passwords) are Secondary Navy at 50% opacity.

### Animated Graphs
Charts should use smooth Bézier curves rather than jagged lines. Use the Accent color (#00D1FF) for the primary data line with a subtle gradient fill underneath that fades to 0% opacity.

### Chips & Badges
Small, high-contrast badges for "Completed," "Pending," or "Declined" statuses. These use the semantic colors with a 10% opacity background and 100% opacity text for high legibility.

### Progress Indicators
Thin, 4px rounded bars using a secondary-to-accent gradient to visualize financial goals or account limits.